var jeden = require('./jeden');

jeden.jeden("Uwielbiam robić zadania z weppo!");